const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const sleep = ms => new Promise(r => setTimeout(r, ms));

const DIR01 = path.join(__dirname, '01-客户管理/screenshots');
const DIR02 = path.join(__dirname, '02-销售管理/screenshots');
const DIR03 = path.join(__dirname, '03-权限安全/screenshots');
[DIR01, DIR02, DIR03].forEach(d => fs.mkdirSync(d, { recursive: true }));

// Clear old screenshots
[DIR01, DIR02, DIR03].forEach(d => {
  fs.readdirSync(d).forEach(f => { try { fs.unlinkSync(path.join(d, f)); } catch(e){} });
});

(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const p = await ctx.newPage();

  // ============================================================
  // SUITECRM: 01-客户管理 + 02-销售管理
  // ============================================================
  console.log('=== SuiteCRM Login ===');
  await p.goto('http://localhost:8072', { waitUntil: 'domcontentloaded' });
  await sleep(3000);
  try { await p.locator('input[name="username"]').first().fill('admin'); } catch(e) {}
  try { await p.locator('input[name="password"]').fill('admin123'); } catch(e) {}
  await p.locator('button').filter({ hasText: /Log ?in/i }).first().click();
  await sleep(3000);

  // 01-客户管理
  console.log('\n=== 01-客户管理 ===');
  await p.goto('http://localhost:8072/#/accounts/index', { waitUntil: 'domcontentloaded' });
  await sleep(3000);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户列表页.png') });
  console.log('[OK] SuiteCRM_客户列表页.png');

  await p.locator('button').filter({ hasText: 'Filter' }).first().click({ force: true });
  await sleep(1500);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户筛选器.png') });
  console.log('[OK] SuiteCRM_客户筛选器.png');

  await p.goto('http://localhost:8072/#/accounts/index', { waitUntil: 'domcontentloaded' });
  await sleep(2000);
  await p.locator('input[name="search-bar-term"], input[placeholder="Search"]').fill('阿里');
  await sleep(2000);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户搜索.png') });
  console.log('[OK] SuiteCRM_客户搜索.png');

  await p.goto('http://localhost:8072/#/accounts/index', { waitUntil: 'domcontentloaded' });
  await sleep(2000);
  try { await p.locator('thead input[type="checkbox"]').first().click({ force: true }); await sleep(500); } catch(e) {}
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户批量操作.png') });
  console.log('[OK] SuiteCRM_客户批量操作.png');

  const firstAcc = p.locator('table tbody tr td a').first();
  if (await firstAcc.count()) {
    await firstAcc.click({ force: true });
    await sleep(2500);
    await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户详情页.png') });
    console.log('[OK] SuiteCRM_客户详情页.png');
  }

  await p.goto('http://localhost:8072/#/accounts/edit', { waitUntil: 'domcontentloaded' });
  await sleep(2000);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_新增客户表单.png') });
  console.log('[OK] SuiteCRM_新增客户表单.png');

  await p.goto('http://localhost:8072/#/accounts/index', { waitUntil: 'domcontentloaded' });
  await sleep(2000);
  await p.locator('input[name="search-bar-term"], input[placeholder="Search"]').fill('阿里巴巴集团');
  await sleep(2000);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户查重.png') });
  console.log('[OK] SuiteCRM_客户查重.png');

  await p.goto('http://localhost:8072/#/accounts/edit', { waitUntil: 'domcontentloaded' });
  await sleep(2000);
  const ti = await p.locator('input[type="text"]').all();
  if (ti.length > 0) { await ti[0].fill('测试编辑公司'); await sleep(500); }
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户编辑页.png') });
  console.log('[OK] SuiteCRM_客户编辑页.png');

  await p.goto('http://localhost:8072/#/contacts/index', { waitUntil: 'domcontentloaded' });
  await sleep(2500);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_联系人管理.png') });
  console.log('[OK] SuiteCRM_联系人管理.png');

  await p.goto('http://localhost:8072/#/accounts/index', { waitUntil: 'domcontentloaded' });
  await sleep(2500);
  await p.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户标签分类.png') });
  console.log('[OK] SuiteCRM_客户标签分类.png');

  // 02-销售管理
  console.log('\n=== 02-销售管理 ===');
  await p.goto('http://localhost:8072/#/leads/index', { waitUntil: 'domcontentloaded' });
  await sleep(3000);
  await p.screenshot({ path: path.join(DIR02, 'SuiteCRM_线索列表页.png') });
  console.log('[OK] SuiteCRM_线索列表页.png');

  const firstLead = p.locator('table tbody tr td a').first();
  if (await firstLead.count()) {
    await firstLead.click({ force: true });
    await sleep(2500);
    await p.screenshot({ path: path.join(DIR02, 'SuiteCRM_线索转化.png') });
    console.log('[OK] SuiteCRM_线索转化.png');
  }

  await p.goto('http://localhost:8072/#/opportunities/index', { waitUntil: 'domcontentloaded' });
  await sleep(3000);
  await p.screenshot({ path: path.join(DIR02, 'SuiteCRM_商机列表页.png') });
  console.log('[OK] SuiteCRM_商机列表页.png');

  const firstOpp = p.locator('table tbody tr td a').first();
  if (await firstOpp.count()) {
    await firstOpp.click({ force: true });
    await sleep(2500);
    await p.screenshot({ path: path.join(DIR02, 'SuiteCRM_商机详情页.png') });
    console.log('[OK] SuiteCRM_商机详情页.png');
  }

  // Vtiger
  console.log('\n=== Vtiger ===');
  try {
    await p.goto('http://localhost:8073', { waitUntil: 'domcontentloaded', timeout: 10000 });
    await sleep(3000);
    try { await p.locator('input[name="user_name"]').first().fill('admin'); } catch(e) {}
    try { await p.locator('input[name="user_password"]').fill('admin'); } catch(e) {}
    const vtLogin = p.locator('button[type="submit"], input[type="submit"]').first();
    if (await vtLogin.count()) { await vtLogin.click({ force: true }); await sleep(3000); }
    await p.goto('http://localhost:8073/index.php?module=Leads&view=List', { waitUntil: 'domcontentloaded' });
    await sleep(2000);
    await p.screenshot({ path: path.join(DIR02, 'Vtiger_线索评分.png') });
    console.log('[OK] Vtiger_线索评分.png');
  } catch(e) {
    console.log('[SKIP] Vtiger:', e.message);
  }

  // ============================================================
  // ODOO: 01-客户管理 + 03-权限安全
  // ============================================================
  console.log('\n=== Odoo Login ===');
  await p.goto('http://localhost:8069/web/login', { waitUntil: 'domcontentloaded' });
  await sleep(3000);

  // Fill login
  await p.locator('input[name="login"]').fill('admin');
  await sleep(500);
  await p.locator('input[name="password"]').fill('admin');
  await sleep(500);
  await p.locator('button[type="submit"]').click();
  await sleep(5000);

  // Handle database selection if shown
  const currentUrl = p.url();
  console.log('After login URL:', currentUrl);

  // Check for database selection page
  if (currentUrl.includes('/web/database/manager') || currentUrl.includes('/web/database/selector')) {
    console.log('Database selection page detected');
    // Click on the odoo_crm database
    const dbLinks = p.locator('a.o_database_list_item, .o_database_list a');
    if (await dbLinks.count()) {
      await dbLinks.first().click();
      await sleep(3000);
    } else {
      // Try clicking on the database card
      const dbCards = p.locator('.o_database_list .o_database_card, .o_database_item');
      if (await dbCards.count()) {
        await dbCards.first().click();
        await sleep(3000);
      }
    }
  }

  console.log('Post-selection URL:', p.url());

  // If we're on a setup wizard, skip it
  if (p.url().includes('/web/login') || p.url().includes('/odoo')) {
    console.log('On login/odoo page, trying to navigate to contacts');
    await p.goto('http://localhost:8069/web#action=base.action_partner_form&view_type=list&cids=1', { waitUntil: 'domcontentloaded', timeout: 15000 });
    await sleep(3000);
  }

  // Take a debug screenshot
  await p.screenshot({ path: '/tmp/odoo_debug.png' });

  // Create Odoo contacts via API
  console.log('\n=== Creating Odoo contacts via API ===');
  const contacts = [
    { name: '阿里巴巴集团', phone: '0571-88888888', email: 'contact@alibaba.com', city: '杭州' },
    { name: '腾讯科技有限公司', phone: '0755-86013388', email: 'contact@tencent.com', city: '深圳' },
    { name: '华为技术有限公司', phone: '0755-28780808', email: 'contact@huawei.com', city: '深圳' },
    { name: '比亚迪股份有限公司', phone: '0755-89888888', email: 'contact@byd.com', city: '深圳' },
    { name: '小米集团', phone: '010-60606666', email: 'contact@xiaomi.com', city: '北京' },
    { name: '京东集团', phone: '010-89123456', email: 'contact@jd.com', city: '北京' },
    { name: '美团科技有限公司', phone: '010-59752000', email: 'contact@meituan.com', city: '北京' },
  ];

  // Get session cookies first
  const cookies = await p.context().cookies();
  const sessionId = cookies.find(c => c.name === 'session_id')?.value;

  if (sessionId) {
    for (const c of contacts) {
      try {
        const resp = await p.request.post('http://localhost:8069/web/dataset/call_kw/res.partner/create', {
          headers: {
            'Content-Type': 'application/json',
            'Cookie': `session_id=${sessionId}`
          },
          data: JSON.stringify({
            jsonrpc: '2.0',
            method: 'call',
            params: {
              model: 'res.partner',
              method: 'create',
              args: [[{
                name: c.name,
                phone: c.phone,
                email: c.email,
                city: c.city,
                type: 'company',
                is_company: true
              }]],
              kwargs: { context: {} }
            }
          })
        });
        const rd = await resp.json();
        console.log(`  Created contact: ${c.name} (ID: ${rd.result || 'unknown'})`);
        await sleep(300);
      } catch(e) {
        console.log(`  Failed to create ${c.name}:`, e.message);
      }
    }
  }

  // Navigate to Contacts app
  console.log('\nNavigating to Odoo contacts...');
  await p.goto('http://localhost:8069/web#view_type=list&model=res.partner&action=base.action_partner_form', { waitUntil: 'domcontentloaded', timeout: 15000 });
  await sleep(4000);

  // Debug: check what page we're on
  const odooUrl = p.url();
  console.log('Odoo contacts URL:', odooUrl);
  const bodyText = await p.locator('body').innerText();
  console.log('Body (first 200):', bodyText.slice(0, 200));

  // If not on contacts, try alternative navigation
  if (bodyText.includes('Contacts') === false && bodyText.includes('contact') === false) {
    console.log('Not on contacts page, trying direct navigation...');
    await p.goto('http://localhost:8069/web#menu_id=5&action=99&view_type=list&model=res.partner', { waitUntil: 'domcontentloaded', timeout: 15000 });
    await sleep(4000);
  }

  // Take another debug screenshot
  await p.screenshot({ path: '/tmp/odoo_debug2.png' });

  // Check if we see contact data
  const hasData = await p.evaluate(() => {
    const rows = document.querySelectorAll('table tbody tr, .o_list_view tbody tr, .o_data_row');
    return rows.length;
  });
  console.log('Odoo rows found:', hasData);

  // 01-客户管理 - Odoo contacts
  await p.screenshot({ path: path.join(DIR01, 'Odoo_客户列表页.png') });
  console.log('[OK] Odoo_客户列表页.png');

  // Odoo contact detail
  const firstOdooContact = p.locator('table tbody tr td a, .o_data_row a, .o_list_view tbody tr a').first();
  if (await firstOdooContact.count()) {
    await firstOdooContact.click({ force: true });
    await sleep(3000);
    await p.screenshot({ path: path.join(DIR01, 'Odoo_客户详情页.png') });
    console.log('[OK] Odoo_客户详情页.png');
    await p.goBack();
    await sleep(2000);
  }

  // 03-权限安全 - Odoo Users & Groups
  console.log('\n=== Odoo Permissions ===');
  await p.goto('http://localhost:8069/web#view_type=list&model=res.users&action=base.action_res_users', { waitUntil: 'domcontentloaded', timeout: 15000 });
  await sleep(4000);
  await p.screenshot({ path: path.join(DIR03, 'Odoo_用户管理页.png') });
  console.log('[OK] Odoo_用户管理页.png');

  // User detail
  const firstUser = p.locator('table tbody tr td a, .o_data_row a').first();
  if (await firstUser.count()) {
    await firstUser.click({ force: true });
    await sleep(3000);
    await p.screenshot({ path: path.join(DIR03, 'Odoo_用户详情页.png') });
    console.log('[OK] Odoo_用户详情页.png');
  }

  // Go to Groups/Roles
  await p.goto('http://localhost:8069/web#view_type=list&model=res.groups&action=base.action_res_groups', { waitUntil: 'domcontentloaded', timeout: 15000 });
  await sleep(4000);
  await p.screenshot({ path: path.join(DIR03, 'Odoo_角色权限配置.png') });
  console.log('[OK] Odoo_角色权限配置.png');

  // Access Rights / Audit log
  await p.goto('http://localhost:8069/web#menu_id=4&action=36&view_type=list&model=res.groups', { waitUntil: 'domcontentloaded', timeout: 15000 });
  await sleep(4000);
  await p.screenshot({ path: path.join(DIR03, 'Odoo_权限安全设置.png') });
  console.log('[OK] Odoo_权限安全设置.png');

  console.log('\n=== All screenshots complete ===');
  await browser.close();
})().catch(e => { console.error('Fatal:', e); process.exit(1); });
