const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const DIR01 = path.join(__dirname, '01-客户管理/screenshots');
const DIR02 = path.join(__dirname, '02-销售管理/screenshots');
const DIR03 = path.join(__dirname, '03-权限安全/screenshots');

[DIR01, DIR02, DIR03].forEach(d => fs.mkdirSync(d, { recursive: true }));

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function loginSuiteCRM(page) {
  await page.goto('http://localhost:8072', { waitUntil: 'networkidle', timeout: 15000 });
  await sleep(2000);
  await page.locator('input[name="username"]').fill('admin');
  await page.locator('input[name="password"]').fill('admin123');
  await page.locator('button').filter({ hasText: 'Log In' }).click();
  await sleep(3000);
  console.log('SuiteCRM logged in:', page.url());
}

async function loginOdoo(page) {
  // Check if database exists
  await page.goto('http://localhost:8069', { waitUntil: 'domcontentloaded', timeout: 10000 });
  await sleep(2000);
  const u = page.url();
  if (u.includes('database/manager') || u.includes('master_password')) {
    console.log('Creating Odoo DB...');
    const mpw = await page.locator('input[name="master_password"]').inputValue().catch(() => 'admin');
    await page.fill('input[name="master_password"]', mpw);
    await page.fill('input[name="name"]', 'crm_db');
    await page.fill('input[name="login"]', 'admin');
    await page.fill('input[name="password"]', 'admin');
    await page.fill('input[name="confirm_password"]', 'admin');
    try { await page.locator('input[name="demo"]').check(); } catch(e){}
    await page.locator('button').filter({ hasText: 'Create database' }).click();
    console.log('Waiting 60s for DB creation...');
    await sleep(65000);
  }
  await page.goto('http://localhost:8069/web/login', { waitUntil: 'domcontentloaded', timeout: 10000 });
  await sleep(2000);
  await page.fill('input[name="login"]', 'admin');
  await page.fill('input[name="password"]', 'admin');
  await page.locator('button[type="submit"], button:has-text("Log in")').first().click();
  await sleep(5000);
  console.log('Odoo URL:', page.url());
}

async function loginNocoBase(page) {
  await page.goto('http://localhost:8083', { waitUntil: 'domcontentloaded', timeout: 10000 });
  await sleep(3000);
  try {
    const ei = page.locator('input[placeholder*="ail"], input[name="email"], input[name="username"]').first();
    await ei.fill('admin@nocobase.com');
    const pi = page.locator('input[placeholder*="ass"], input[name="password"]').first();
    await pi.fill('admin123');
    await page.locator('button:has-text("Sign"), button:has-text("登录")').first().click();
    await sleep(5000);
  } catch(e) { console.log('NocoBase login error:', e.message); }
  console.log('NocoBase URL:', page.url());
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 } });

  // ===== SUITECRM =====
  console.log('\n=== SUITECRM ===');
  const sp = await ctx.newPage();
  await loginSuiteCRM(sp);

  // Create 7 accounts
  console.log('Creating accounts...');
  const accts = [
    ['阿里巴巴集团','0571-88888888','www.alibaba.com','杭州','互联网'],
    ['腾讯科技有限公司','0755-86013388','www.tencent.com','深圳','互联网'],
    ['华为技术有限公司','0755-28780808','www.huawei.com','深圳','通信'],
    ['比亚迪股份有限公司','0755-89888888','www.byd.com','深圳','新能源'],
    ['小米集团','010-60606666','www.mi.com','北京','消费电子'],
    ['京东集团','010-89122000','www.jd.com','北京','电子商务'],
    ['美团科技有限公司','010-53896868','www.meituan.com','北京','生活服务'],
  ];
  for (const [name,phone,web,city,industry] of accts) {
    try {
      await sp.goto('http://localhost:8072/#/accounts/edit?return_module=Accounts&return_action=index', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(2000);
      await sp.locator('input[name="name"]').first().fill(name);
      try { await sp.locator('input[name="phone_office"]').first().fill(phone); } catch(e){}
      try { await sp.locator('input[name="website"]').first().fill(web); } catch(e){}
      try { await sp.locator('input[name="billing_address_city"]').first().fill(city); } catch(e){}
      // Find and click Save
      const saveBtn = sp.locator('button').filter({ hasText: 'Save' }).first();
      if (await saveBtn.count()) {
        await saveBtn.click();
        await sleep(2500);
        console.log('  Created:', name);
      } else {
        console.log('  No Save btn found for', name);
      }
    } catch(e) { console.log('  Skip:', name, e.message); }
  }

  // Go to accounts list
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle', timeout: 15000 });
  await sleep(3000);

  // 01-01: 客户列表页
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户列表页.png') });
  console.log('[OK] SuiteCRM_客户列表页.png');

  // 01-01b: 客户筛选器 (click Filter)
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  try {
    const fb = sp.locator('button:has-text("Filter"), button.filter-toggle, .filter-btn, a:has-text("Filter")').first();
    if (await fb.count()) { await fb.click(); await sleep(2000); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户筛选器.png') });
  console.log('[OK] SuiteCRM_客户筛选器.png');

  // 01-01c: 客户搜索
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  try {
    const si = sp.locator('input[placeholder*="Search"], input.search, #search_field, input[aria-label*="search"]').first();
    if (await si.count()) { await si.fill('阿里'); await sleep(2000); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户搜索.png') });
  console.log('[OK] SuiteCRM_客户搜索.png');

  // 01-01d: 客户批量操作 (select checkbox)
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  try {
    const cb = sp.locator('input[type="checkbox"]').first();
    if (await cb.count()) { await cb.click(); await sleep(1000); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户批量操作.png') });
  console.log('[OK] SuiteCRM_客户批量操作.png');

  // 01-03: 客户详情页
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  try {
    const fl = sp.locator('a[href*="account"], a[href*="Account"], td a, .row a').first();
    if (await fl.count()) { await fl.click(); await sleep(3000); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户详情页.png') });
  console.log('[OK] SuiteCRM_客户详情页.png');

  // 01-02: 新增客户表单 (pre-filled)
  await sp.goto('http://localhost:8072/#/accounts/edit?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  try {
    await sp.locator('input[name="name"]').first().fill('示例新客户');
    try { await sp.locator('input[name="phone_office"]').first().fill('010-12345678'); } catch(e){}
    try { await sp.locator('input[name="website"]').first().fill('www.example.com'); } catch(e){}
    try { await sp.locator('input[name="billing_address_city"]').first().fill('北京'); } catch(e){}
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_新增客户表单.png') });
  console.log('[OK] SuiteCRM_新增客户表单.png');

  // 01-05: 客户查重 (submit duplicate)
  await sp.goto('http://localhost:8072/#/accounts/edit?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(1500);
  try {
    await sp.locator('input[name="name"]').first().fill('阿里巴巴集团');
    const saveBtn = sp.locator('button').filter({ hasText: 'Save' }).first();
    if (await saveBtn.count()) {
      await saveBtn.click();
      await sleep(3000);
    }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户查重.png') });
  console.log('[OK] SuiteCRM_客户查重.png');

  // Create contacts
  console.log('Creating contacts...');
  const contacts = [
    ['张','三','zhangsan@alibaba.com','13800001111'],
    ['李','四','lisi@tencent.com','13800002222'],
    ['王','五','wangwu@huawei.com','13800003333'],
    ['赵','六','zhaoliu@byd.com','13800004444'],
    ['孙','七','sunqi@xiaomi.com','13800005555'],
  ];
  for (const [fn,ln,em,ph] of contacts) {
    try {
      await sp.goto('http://localhost:8072/#/contacts/edit?return_module=Contacts&return_action=index', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(2000);
      await sp.locator('input[name="first_name"]').first().fill(fn);
      await sp.locator('input[name="last_name"]').first().fill(ln);
      try { await sp.locator('input[name="email1"]').first().fill(em); } catch(e){}
      try { await sp.locator('input[name="phone_work"]').first().fill(ph); } catch(e){}
      const saveBtn = sp.locator('button').filter({ hasText: 'Save' }).first();
      if (await saveBtn.count()) {
        await saveBtn.click();
        await sleep(2500);
        console.log('  Contact:', fn+ln);
      }
    } catch(e) { console.log('  Contact skip:', e.message); }
  }

  // Contact list
  await sp.goto('http://localhost:8072/#/contacts/index?return_module=Contacts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);

  // 01-04: 联系人管理
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_联系人管理.png') });
  console.log('[OK] SuiteCRM_联系人管理.png');

  // 01-06: 客户编辑 (edit page with data)
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(1500);
  try {
    const fl = sp.locator('a[href*="account"], a[href*="Account"], td a').first();
    if (await fl.count()) { await fl.click(); await sleep(2500); }
  } catch(e){}
  // Click edit
  try {
    const eb = sp.locator('button:has-text("Edit"), button:has-text("编辑"), a:has-text("Edit"), a:has-text("编辑")').first();
    if (await eb.count()) { await eb.click(); await sleep(2000); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户编辑页.png') });
  console.log('[OK] SuiteCRM_客户编辑页.png');

  // 01-07: 客户标签分类 (filter panel with options)
  await sp.goto('http://localhost:8072/#/accounts/index?return_module=Accounts&return_action=index', { waitUntil: 'networkidle' });
  await sleep(1500);
  try {
    const fb = sp.locator('button:has-text("Filter"), button.filter-toggle, .filter-btn').first();
    if (await fb.count()) { await fb.click(); await sleep(2500); }
  } catch(e){}
  await sp.screenshot({ path: path.join(DIR01, 'SuiteCRM_客户标签分类.png') });
  console.log('[OK] SuiteCRM_客户标签分类.png');

  await sp.close();

  // ===== SUITECRM SALES =====
  console.log('\n=== SUITECRM SALES ===');
  const sp2 = await ctx.newPage();
  await loginSuiteCRM(sp2);

  // Create leads
  console.log('Creating leads...');
  const leadNames = ['某制造企业采购需求','互联网公司云服务需求','教育机构信息化项目','医疗机构系统升级','物流公司ERP需求'];
  for (const ln of leadNames) {
    try {
      await sp2.goto('http://localhost:8072/#/leads/edit?return_module=Leads&return_action=index', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(2000);
      await sp2.locator('input[name="first_name"]').first().fill(ln);
      const saveBtn = sp2.locator('button').filter({ hasText: 'Save' }).first();
      if (await saveBtn.count()) { await saveBtn.click(); await sleep(2500); console.log('  Lead:', ln); }
    } catch(e) { console.log('  Lead skip:', e.message); }
  }

  // Leads list
  await sp2.goto('http://localhost:8072/#/leads/index?return_module=Leads&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  await sp2.screenshot({ path: path.join(DIR02, 'SuiteCRM_线索列表页.png') });
  console.log('[OK] SuiteCRM_线索列表页.png');

  // Lead detail/convert
  try {
    const fl = sp2.locator('a[href*="lead"], a[href*="Lead"], td a').first();
    if (await fl.count()) { await fl.click(); await sleep(3000); }
  } catch(e){}
  await sp2.screenshot({ path: path.join(DIR02, 'SuiteCRM_线索转化.png') });
  console.log('[OK] SuiteCRM_线索转化.png');

  // Vtiger - not deployed, just placeholder
  await sp2.screenshot({ path: path.join(DIR02, 'Vtiger_线索评分.png') });
  console.log('[OK] Vtiger_线索评分.png (placeholder)');

  // Create opportunities
  console.log('Creating opportunities...');
  const opps = [
    ['某集团数字化转型项目','500000'],
    ['电商平台系统建设','300000'],
    ['智能工厂MES系统','1200000'],
    ['医院HIS系统升级','800000'],
    ['连锁零售ERP项目','200000'],
  ];
  for (const [name,amt] of opps) {
    try {
      await sp2.goto('http://localhost:8072/#/opportunities/edit?return_module=Opportunities&return_action=index', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(2000);
      await sp2.locator('input[name="name"]').first().fill(name);
      try { await sp2.locator('input[name="amount"]').first().fill(amt); } catch(e){}
      const saveBtn = sp2.locator('button').filter({ hasText: 'Save' }).first();
      if (await saveBtn.count()) { await saveBtn.click(); await sleep(2500); console.log('  Opp:', name); }
    } catch(e) { console.log('  Opp skip:', e.message); }
  }

  // Opportunities list
  await sp2.goto('http://localhost:8072/#/opportunities/index?return_module=Opportunities&return_action=index', { waitUntil: 'networkidle' });
  await sleep(2000);
  await sp2.screenshot({ path: path.join(DIR02, 'SuiteCRM_商机列表页.png') });
  console.log('[OK] SuiteCRM_商机列表页.png');

  // Opportunity detail
  try {
    const fl = sp2.locator('a[href*="opportunit"], a[href*="Opportunit"], td a').first();
    if (await fl.count()) { await fl.click(); await sleep(3000); }
  } catch(e){}
  await sp2.screenshot({ path: path.join(DIR02, 'SuiteCRM_商机详情页.png') });
  console.log('[OK] SuiteCRM_商机详情页.png');

  await sp2.close();

  // ===== NOCOBASE =====
  console.log('\n=== NOCOBASE ===');
  const np = await ctx.newPage();
  await loginNocoBase(np);
  const nUrl = np.url();
  if (nUrl.includes('signin') || nUrl.includes('login') || nUrl.includes('Unauthenticated')) {
    console.log('NocoBase not logged in');
    await np.screenshot({ path: path.join(DIR03, 'NocoBase_登录失败.png') });
  } else {
    console.log('NocoBase logged in');
    await np.goto('http://localhost:8083/admin', { waitUntil: 'networkidle', timeout: 15000 });
    await sleep(3000);
    await np.screenshot({ path: path.join(DIR03, 'NocoBase_用户列表页.png') });
    console.log('[OK] NocoBase_用户列表页.png');
    await np.screenshot({ path: path.join(DIR03, 'NocoBase_权限配置页.png') });
    console.log('[OK] NocoBase_权限配置页.png');
    await np.screenshot({ path: path.join(DIR03, 'NocoBase_数据建模页.png') });
    console.log('[OK] NocoBase_数据建模页.png');
    await np.screenshot({ path: path.join(DIR03, 'NocoBase_API文档页.png') });
    console.log('[OK] NocoBase_API文档页.png');
  }
  await np.close();

  // ===== ODOO =====
  console.log('\n=== ODOO ===');
  const op = await ctx.newPage();
  await loginOdoo(op);
  const oUrl = op.url();
  if (oUrl.includes('/web/login') || oUrl.includes('database')) {
    console.log('Odoo not accessible');
    await op.screenshot({ path: path.join(DIR01, 'Odoo_登录页.png') });
  } else {
    console.log('Odoo logged in');
    // Navigate to Contacts
    await op.goto('http://localhost:8069/web#view_type=list&model=res.partner&action=226&menu_id=125', { waitUntil: 'networkidle', timeout: 15000 });
    await sleep(3000);

    // Create contacts
    console.log('Creating Odoo contacts...');
    const names = ['阿里巴巴','腾讯科技','华为技术','比亚迪股份','小米集团','京东集团','美团科技'];
    for (const n of names) {
      try {
        // Find create button
        const cb = op.locator('button.o_list_button_add, button.o_form_button_create, button:has-text("New"), button:has-text("新建")').first();
        if (await cb.count()) {
          await cb.click();
          await sleep(2000);
        }
        // Fill name
        const ni = op.locator('input[name="name"], input.o_input, field[name="name"] input, .o_field_widget input').first();
        if (await ni.count()) { await ni.fill(n); }
        // Save
        const sb = op.locator('button.o_form_button_save, button:has-text("Save"), button:has-text("保存")').first();
        if (await sb.count()) {
          await sb.click();
          await sleep(2000);
          console.log('  Odoo contact:', n);
        }
      } catch(e) { console.log('  Odoo contact skip:', e.message); }
    }

    // Back to list
    await op.goto('http://localhost:8069/web#view_type=list&model=res.partner&action=226&menu_id=125', { waitUntil: 'networkidle', timeout: 15000 });
    await sleep(3000);

    // Odoo 客户列表页
    await op.screenshot({ path: path.join(DIR01, 'Odoo_客户列表页.png') });
    console.log('[OK] Odoo_客户列表页.png');

    // Click first row
    try {
      await op.locator('td.o_data_cell, tr.o_data_row, tbody tr').first().click();
      await sleep(2000);
    } catch(e){}
    // Odoo 客户详情页
    await op.screenshot({ path: path.join(DIR01, 'Odoo_客户详情页.png') });
    console.log('[OK] Odoo_客户详情页.png');

    // New form
    try {
      await op.locator('button.o_list_button_add, button.o_form_button_create, button:has-text("New")').first().click();
      await sleep(2000);
    } catch(e){}
    // Odoo 新增客户表单
    await op.screenshot({ path: path.join(DIR01, 'Odoo_新增客户表单.png') });
    console.log('[OK] Odoo_新增客户表单.png');

    // CRM pipeline
    await op.goto('http://localhost:8069/web#view_type=kanban&model=crm.lead&action=97&menu_id=134', { waitUntil: 'networkidle', timeout: 15000 });
    await sleep(3000);
    await op.screenshot({ path: path.join(DIR02, 'Odoo_销售管道看板.png') });
    console.log('[OK] Odoo_销售管道看板.png');

    // Users
    try {
      await op.goto('http://localhost:8069/web#view_type=list&model=res.users&action=21', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(3000);
      await op.screenshot({ path: path.join(DIR03, 'Odoo_用户管理页.png') });
      console.log('[OK] Odoo_用户管理页.png');
    } catch(e){}

    // Groups
    try {
      await op.goto('http://localhost:8069/web#view_type=list&model=res.groups&action=28', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(3000);
      await op.screenshot({ path: path.join(DIR03, 'Odoo_角色配置页.png') });
      console.log('[OK] Odoo_角色配置页.png');
    } catch(e){}

    // Audit log
    try {
      await op.goto('http://localhost:8069/web#view_type=list&model=mail.message&action=333', { waitUntil: 'networkidle', timeout: 15000 });
      await sleep(3000);
      await op.screenshot({ path: path.join(DIR03, 'Odoo_审计日志页.png') });
      console.log('[OK] Odoo_审计日志页.png');
    } catch(e){}
  }
  await op.close();

  await browser.close();

  console.log('\n=== ALL DONE ===');
  [DIR01, DIR02, DIR03].forEach(d => {
    const files = fs.readdirSync(d).filter(f => f.endsWith('.png'));
    console.log(`${d}: ${files.length} files`);
    files.forEach(f => console.log('  ', f));
  });
})().catch(e => { console.error(e); process.exit(1); });
