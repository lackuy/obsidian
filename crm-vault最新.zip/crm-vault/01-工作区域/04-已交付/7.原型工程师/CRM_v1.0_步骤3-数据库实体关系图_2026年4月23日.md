# CRM_v1.0_步骤3-数据库实体关系图_2026年4月23日

> **项目名称**: CRM 客户关系管理系统
> **版本**: v1.0
> **日期**: 2026-04-23

---

## 文档溯源

### 任务来源
| 项目 | 内容 |
|------|------|
| **任务名称** | CRM 系统产品实施 |
| **需求来源** | [[01-工作区域/00-需求池/00001.CRM系统的功能合并报告+-20260407]] |

### 上游文档
| 角色 | 文档链接 |
|------|---------|
| 产品分析师 | [[01_v1.0_客户管理子PRD]], [[02_v1.0_销售管理子PRD]], [[03_v1.0_权限安全子PRD]] |

---

## 全局 ER 关系图

```mermaid
erDiagram
    %% ========== 权限安全模块 ==========
    user {
        VARCHAR id PK
        VARCHAR name
        VARCHAR email UK
        VARCHAR password_hash
        VARCHAR avatar
        VARCHAR department_id
        BOOLEAN active
        DATETIME last_login_at
        DATETIME created_at
        DATETIME updated_at
    }

    role {
        VARCHAR id PK
        VARCHAR name UK
        TEXT description
        VARCHAR parent_id FK
        DATETIME created_at
        DATETIME updated_at
    }

    user_role {
        VARCHAR id PK
        VARCHAR user_id FK
        VARCHAR role_id FK
        DATETIME created_at
    }

    role_permission {
        VARCHAR id PK
        VARCHAR role_id FK
        VARCHAR resource
        ENUM row_scope
        ENUM field_level
        JSON operations
    }

    audit_log {
        VARCHAR id PK
        VARCHAR user_id FK
        ENUM action
        VARCHAR resource
        VARCHAR resource_id
        JSON changes
        VARCHAR ip
        DATETIME created_at
    }

    api_token {
        VARCHAR id PK
        VARCHAR user_id FK
        VARCHAR name
        VARCHAR token_hash
        JSON permissions
        DATETIME expires_at
        DATETIME created_at
    }

    oauth2_provider {
        VARCHAR id PK
        VARCHAR provider
        VARCHAR client_id
        VARCHAR client_secret
        VARCHAR redirect_uri
        JSON scopes
        BOOLEAN enabled
    }

    oauth2_user_binding {
        VARCHAR id PK
        VARCHAR user_id FK
        VARCHAR provider
        VARCHAR provider_user_id
        DATETIME created_at
    }

    %% ========== 客户管理模块 ==========
    customer {
        VARCHAR id PK
        VARCHAR name UK
        VARCHAR contact_name
        VARCHAR phone
        VARCHAR email UK
        ENUM grade
        ENUM status
        VARCHAR owner_id FK
        VARCHAR source
        VARCHAR industry
        TEXT address
        TEXT note
        BOOLEAN is_deleted
        DATETIME deleted_at
        DATETIME created_at
        DATETIME updated_at
    }

    contact {
        VARCHAR id PK
        VARCHAR customer_id FK
        VARCHAR name
        VARCHAR title
        VARCHAR phone
        VARCHAR email
        BOOLEAN is_primary
        DATETIME created_at
        DATETIME updated_at
    }

    customer_change_log {
        VARCHAR id PK
        VARCHAR customer_id FK
        VARCHAR field_name
        TEXT old_value
        TEXT new_value
        VARCHAR operator_id FK
        DATETIME created_at
    }

    %% ========== 销售管理模块 ==========
    lead {
        VARCHAR id PK
        VARCHAR name
        VARCHAR source
        VARCHAR industry
        VARCHAR contact
        VARCHAR phone
        VARCHAR email
        VARCHAR company
        INT score
        ENUM status
        VARCHAR owner_id FK
        BOOLEAN converted
        VARCHAR converted_account_id FK
        VARCHAR converted_contact_id FK
        VARCHAR converted_opportunity_id FK
        DATETIME created_at
        DATETIME updated_at
    }

    opportunity {
        VARCHAR id PK
        VARCHAR name
        VARCHAR account_id FK
        ENUM stage
        DECIMAL amount
        INT probability
        DECIMAL weighted_amount
        DATE close_date
        VARCHAR owner_id FK
        ENUM status
        TEXT note
        DATETIME created_at
        DATETIME updated_at
    }

    quote {
        VARCHAR id PK
        VARCHAR opportunity_id FK
        VARCHAR quote_number UK
        VARCHAR name
        INT version
        DECIMAL subtotal
        DECIMAL discount
        DECIMAL tax
        DECIMAL total
        ENUM status
        DATE valid_until
        TEXT note
        DATETIME created_at
        DATETIME updated_at
    }

    quote_line_item {
        VARCHAR id PK
        VARCHAR quote_id FK
        VARCHAR product_name
        INT quantity
        DECIMAL unit_price
        DECIMAL discount
        DECIMAL total
    }

    opportunity_stage_history {
        VARCHAR id PK
        VARCHAR opportunity_id FK
        ENUM from_stage
        ENUM to_stage
        VARCHAR operator_id FK
        DATETIME created_at
    }

    %% ========== 权限安全关系 ==========
    user ||--o{ user_role : "拥有"
    role ||--o{ user_role : "被分配"
    role ||--o{ role : "继承(parent_id)"
    role ||--o{ role_permission : "配置"
    user ||--o{ audit_log : "执行操作"
    user ||--o{ api_token : "创建"
    user ||--o{ oauth2_user_binding : "绑定"
    oauth2_provider ||--o{ oauth2_user_binding : "提供商"

    %% ========== 客户管理关系 ==========
    user ||--o{ customer : "负责人(owner_id)"
    customer ||--o{ contact : "关联"
    customer ||--o{ customer_change_log : "变更记录"
    user ||--o{ customer_change_log : "操作人"

    %% ========== 销售管理关系 ==========
    user ||--o{ lead : "负责人(owner_id)"
    lead ||--o| customer : "转化为(converted_account_id)"
    lead ||--o| contact : "转化为(converted_contact_id)"
    lead ||--o| opportunity : "转化为(converted_opportunity_id)"
    customer ||--o{ opportunity : "关联(account_id)"
    user ||--o{ opportunity : "负责人(owner_id)"
    opportunity ||--o{ quote : "关联"
    quote ||--o{ quote_line_item : "明细"
    opportunity ||--o{ opportunity_stage_history : "阶段历史"
    user ||--o{ opportunity_stage_history : "操作人"
```

---

## 实体关系说明

### 核心业务流

```
lead(线索) ──转化──▶ customer(客户) ──关联──▶ opportunity(商机) ──关联──▶ quote(报价)
                                                │
                                                └── opportunity_stage_history(阶段历史)
```

### 权限控制流

```
user(用户) ──分配──▶ user_role(用户角色) ──继承──▶ role(角色) ──配置──▶ role_permission(权限)
   │
   └── 所有操作 ──记录──▶ audit_log(审计日志)
```

### 数据归属

- `customer.owner_id` → 客户负责人（行级权限控制）
- `opportunity.owner_id` → 商机负责人（行级权限控制）
- `lead.owner_id` → 线索负责人（行级权限控制）
- `contact.customer_id` → 联系人归属客户（1对多）

---

## 版本记录

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v1.0 | 2026-04-23 | 初始版本，整合三个子PRD的全部数据库表 |
