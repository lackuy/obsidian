# CRM_v1.0_步骤3-数据库实体关系图_2026年4月30日

> **项目名称**: CRM 客户关系管理系统
> **版本**: v1.0
> **日期**: 2026-04-30

---

## 文档溯源

### 任务来源
| 项目 | 内容 |
|------|------|
| **任务名称** | CRM 系统产品实施 |
| **需求来源** | [[01-工作区域/00-需求池/00001.CRM系统的功能合并报告+-20260407]] |

### 上游文档
| 角色 | 文档链接 |
|------|---------|
| 产品分析师 | [[01_v1.0_客户管理子PRD]], [[02_v1.0_销售管理子PRD]], [[03_v1.0_权限安全子PRD]] |
| 原型工程师 | [[CRM_v1.0_步骤1-主PRD_2026年4月30日]] |

---

## 一、系统表总览

### 1.1 按业务分类

| 分类 | 表名 | 中文名 | 所属模块 | 说明 |
|------|------|--------|----------|------|
| **核心业务表** | customer | 客户表 | CRM-01 | 客户基本信息与生命周期管理 |
| | contact | 联系人表 | CRM-01 | 客户关联联系人（1对多） |
| | lead | 线索表 | CRM-02 | 销售线索全生命周期 |
| | opportunity | 商机表 | CRM-02 | 商机管理与销售阶段 |
| | quote | 报价表 | CRM-02 | 报价单管理（多版本） |
| | quote_line_item | 报价明细表 | CRM-02 | 报价产品明细 |
| **用户权限表** | user | 用户表 | CRM-03 | 系统用户管理 |
| | role | 角色表 | CRM-03 | 角色定义与继承 |
| | user_role | 用户角色关联表 | CRM-03 | 用户-角色多对多 |
| | role_permission | 角色权限表 | CRM-03 | 权限矩阵配置 |
| **关联记录表** | customer_change_log | 客户变更日志表 | CRM-01 | 字段级变更追溯 |
| | opportunity_stage_history | 商机阶段历史表 | CRM-02 | 商机阶段流转记录 |
| **安全审计表** | audit_log | 审计日志表 | CRM-03 | 全操作审计追溯 |
| | api_token | API Token表 | CRM-03 | API认证令牌管理 |
| **集成认证表** | oauth2_provider | OAuth2提供商表 | CRM-03 | OAuth2服务商配置 |
| | oauth2_user_binding | OAuth2用户绑定表 | CRM-03 | 第三方账号关联 |

> **总计**: 16张表（6张核心业务表 + 4张用户权限表 + 2张关联记录表 + 4张安全与集成表）

---

## 二、核心业务流转

```
线索(lead) ──转化──▶ 客户(customer) ──关联──▶ 联系人(contact)
                       │                           │
                       │ 生成                      │ 1对多
                       ▼                           │
                    商机(opportunity) ◄─────────────┘
                       │
                       │ 关联
                       ▼
                    报价(quote) ──明细──▶ 报价明细(quote_line_item)
                       │
                       │ 转订单
                       ▼
                    成交（更新opportunity.status='won'）

权限层：
用户(user) ──分配──▶ 用户角色(user_role) ◄──分配── 角色(role)
                                                     │
                                                     │ 配置
                                                     ▼
                                              角色权限(role_permission)
                                                     │
                          ┌──────────────────────────┼──────────────────────────┐
                          ▼                          ▼                          ▼
                    行级数据范围                  字段级权限                  操作级权限
                   (self/dept/all)          (hidden/readonly/edit)    (create/read/update/delete)

审计层：
所有操作 ──记录──▶ 审计日志(audit_log)
API调用 ──Token认证──▶ api_token ──权限校验──▶ 业务接口
第三方登录 ──OAuth2──▶ oauth2_provider ──绑定──▶ oauth2_user_binding ──关联──▶ user
```

---

## 三、按模块 ERD 关系图

### 3.1 CRM-01 客户管理模块 ERD

```mermaid
erDiagram
    customer {
        varchar id PK "主键 UUID"
        varchar name UK "客户名称 唯一"
        varchar contact_name "主联系人姓名"
        varchar phone "联系电话"
        varchar email UK "联系邮箱 唯一"
        enum grade "客户分级 A/B/C/D"
        enum status "状态 potential/following/won/lost"
        varchar owner_id FK "负责人用户ID"
        varchar source "客户来源"
        varchar industry "行业"
        text address "详细地址"
        text note "备注"
        boolean is_deleted "软删除标记"
        datetime deleted_at "删除时间"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    contact {
        varchar id PK "主键 UUID"
        varchar customer_id FK "关联客户ID"
        varchar name "联系人姓名"
        varchar title "职位"
        varchar phone "联系电话"
        varchar email "联系邮箱"
        boolean is_primary "是否主联系人"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    customer_change_log {
        varchar id PK "主键 UUID"
        varchar customer_id FK "关联客户ID"
        varchar field_name "变更字段名"
        text old_value "变更前值"
        text new_value "变更后值"
        varchar operator_id FK "操作人用户ID"
        datetime created_at "变更时间"
    }

    customer ||--o{ contact : "1对多 关联"
    customer ||--o{ customer_change_log : "1对多 变更追溯"
```

### 3.2 CRM-02 销售管理模块 ERD

```mermaid
erDiagram
    lead {
        varchar id PK "主键 UUID"
        varchar name "线索名称"
        varchar source "来源 website/referral/exhibition/ad"
        varchar industry "行业"
        varchar contact "联系人"
        varchar phone "联系电话"
        varchar email "邮箱"
        varchar company "公司名"
        int score "线索评分 0-100"
        enum status "状态 new/following/converted/closed"
        varchar owner_id FK "负责人用户ID"
        boolean converted "是否已转化"
        varchar converted_account_id FK "转化后客户ID"
        varchar converted_contact_id FK "转化后联系人ID"
        varchar converted_opportunity_id FK "转化后商机ID"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    opportunity {
        varchar id PK "主键 UUID"
        varchar name "商机名称"
        varchar account_id FK "关联客户ID"
        enum stage "销售阶段 qualification/needs_analysis/proposal/negotiation/won/lost"
        decimal amount "预计金额"
        int probability "成功概率 0-100"
        decimal weighted_amount "加权金额 amount*probability"
        date close_date "预计成交日期"
        varchar owner_id FK "负责人用户ID"
        enum status "状态 open/won/lost"
        text note "备注"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    quote {
        varchar id PK "主键 UUID"
        varchar opportunity_id FK "关联商机ID"
        varchar quote_number UK "报价编号 Q-YYYY-NNN"
        varchar name "报价名称"
        int version "版本号 递增"
        decimal subtotal "小计"
        decimal discount "折扣"
        decimal tax "税费"
        decimal total "总计"
        enum status "状态 draft/sent/accepted/rejected"
        date valid_until "有效期至"
        text note "备注"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    quote_line_item {
        varchar id PK "主键 UUID"
        varchar quote_id FK "关联报价ID"
        varchar product_name "产品/服务名称"
        int quantity "数量"
        decimal unit_price "单价"
        decimal discount "折扣"
        decimal total "小计"
    }

    opportunity_stage_history {
        varchar id PK "主键 UUID"
        varchar opportunity_id FK "关联商机ID"
        enum from_stage "原阶段"
        enum to_stage "目标阶段"
        varchar operator_id FK "操作人"
        datetime created_at "变更时间"
    }

    lead ||--o| customer : "转化 1对0..1"
    lead ||--o| contact : "转化 1对0..1"
    lead ||--o| opportunity : "转化 1对0..1"
    opportunity ||--o{ quote : "关联 1对多"
    quote ||--o{ quote_line_item : "明细 1对多"
    opportunity ||--o{ opportunity_stage_history : "记录 1对多"
```

### 3.3 CRM-03 权限安全模块 ERD

```mermaid
erDiagram
    user {
        varchar id PK "主键 UUID"
        varchar name "姓名"
        varchar email UK "邮箱 唯一"
        varchar password_hash "密码哈希 bcrypt"
        varchar avatar "头像URL"
        varchar department_id "部门ID"
        boolean active "是否启用"
        datetime last_login_at "最后登录时间"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    role {
        varchar id PK "主键 UUID"
        varchar name UK "角色名称 唯一"
        text description "角色描述"
        varchar parent_id FK "父角色ID 继承"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    user_role {
        varchar id PK "主键 UUID"
        varchar user_id FK "用户ID"
        varchar role_id FK "角色ID"
        datetime created_at "创建时间"
    }

    role_permission {
        varchar id PK "主键 UUID"
        varchar role_id FK "角色ID"
        varchar resource "资源名"
        enum row_scope "数据范围 self/department/all"
        enum field_level "字段级别 hidden/readonly/edit"
        json operations "允许操作 create/read/update/delete"
    }

    audit_log {
        varchar id PK "主键 UUID"
        varchar user_id FK "操作人用户ID"
        enum action "操作类型 create/update/delete"
        varchar resource "资源名"
        varchar resource_id "资源ID"
        json changes "变更前后对比"
        varchar ip "操作人IP"
        datetime created_at "操作时间"
    }

    api_token {
        varchar id PK "主键 UUID"
        varchar user_id FK "所属用户ID"
        varchar name "Token名称"
        varchar token_hash "Token哈希值"
        json permissions "限定权限范围"
        datetime expires_at "过期时间"
        datetime created_at "创建时间"
    }

    oauth2_provider {
        varchar id PK "主键 UUID"
        varchar provider "提供商名称 Google/GitHub/企业微信"
        varchar client_id "OAuth2 Client ID"
        varchar client_secret "OAuth2 Client Secret"
        varchar redirect_uri "回调地址"
        json scopes "授权范围"
        boolean enabled "是否启用"
    }

    oauth2_user_binding {
        varchar id PK "主键 UUID"
        varchar user_id FK "本地用户ID"
        varchar provider "提供商"
        varchar provider_user_id "第三方用户ID"
        datetime created_at "创建时间"
    }

    user ||--o{ user_role : "分配 1对多"
    role ||--o{ user_role : "被分配 1对多"
    role ||--o{ role_permission : "配置 1对多"
    role ||--o| role : "继承 1对0..1"
    user ||--o{ audit_log : "产生 1对多"
    user ||--o{ api_token : "拥有 1对多"
    user ||--o{ oauth2_user_binding : "绑定 1对多"
    oauth2_provider ||--o{ oauth2_user_binding : "认证 1对多"
```

### 3.4 跨模块全局 ERD（简化视图）

```mermaid
erDiagram
    customer ||--o{ contact : "has"
    customer ||--o{ opportunity : "generates"
    customer ||--o{ customer_change_log : "tracks"
    opportunity ||--o{ opportunity_stage_history : "records"
    opportunity ||--o{ quote : "has"
    quote ||--o{ quote_line_item : "contains"
    lead ||--o| customer : "converts_to"
    lead ||--o| contact : "converts_to"
    lead ||--o| opportunity : "converts_to"
    
    user ||--o{ user_role : "assigned"
    role ||--o{ user_role : "assigned_to"
    role ||--o{ role_permission : "configures"
    
    user ||--o{ audit_log : "generates"
    user ||--o{ api_token : "owns"
    user ||--o{ oauth2_user_binding : "binds"
    oauth2_provider ||--o{ oauth2_user_binding : "authenticates"
    
    user ||--o{ customer : "owns"
    user ||--o{ lead : "owns"
    user ||--o{ opportunity : "owns"
```

---

## 四、关系符号对照表

| 符号 | 含义 | 示例 | 说明 |
|------|------|------|------|
| `||--o{` | 1对多 | `customer \|\|--o{ contact` | 一个客户有多个联系人 |
| `||--o|` | 1对0..1 | `lead \|\|--o\| customer` | 线索转化生成0或1个客户 |
| `||--||` | 1对1 | `user \|\|--\|\| profile` | 一个用户一个档案 |
| `}o--o{` | 多对多 | `user }o--o{ role` | 用户角色多对多（通过关联表） |
| `||--o{` (FK) | 外键关联 | `opportunity.customer_id` | 商机关联客户 |

---

## 五、所有连线汇总

### 5.1 一对多关系（||--o{）

| 父表 | 子表 | 外键 | 业务含义 |
|------|------|------|----------|
| customer | contact | contact.customer_id | 一个客户有多个联系人 |
| customer | opportunity | opportunity.account_id | 一个客户产生多个商机 |
| customer | customer_change_log | customer_change_log.customer_id | 一个客户多次变更记录 |
| opportunity | opportunity_stage_history | opportunity_stage_history.opportunity_id | 商机多次阶段流转 |
| opportunity | quote | quote.opportunity_id | 一个商机多次报价 |
| quote | quote_line_item | quote_line_item.quote_id | 报价含多条明细 |
| user | user_role | user_role.user_id | 用户分配多个角色 |
| role | user_role | user_role.role_id | 角色被多个用户引用 |
| role | role_permission | role_permission.role_id | 角色有多条权限配置 |
| user | audit_log | audit_log.user_id | 用户产生多条操作记录 |
| user | api_token | api_token.user_id | 用户拥有多个API Token |
| user | oauth2_user_binding | oauth2_user_binding.user_id | 用户绑定多个第三方 |
| oauth2_provider | oauth2_user_binding | oauth2_user_binding.provider | 提供商多个用户绑定 |

### 5.2 一对零或一关系（||--o|）

| 父表 | 子表 | 外键 | 业务含义 |
|------|------|------|----------|
| lead | customer | lead.converted_account_id | 线索转化生成0或1个客户 |
| lead | contact | lead.converted_contact_id | 线索转化生成0或1个联系人 |
| lead | opportunity | lead.converted_opportunity_id | 线索转化生成0或1个商机 |
| role | role | role.parent_id | 角色继承0或1个父角色 |

---

## 六、自研建议

| 建议项 | 说明 | 优先级 |
|--------|------|--------|
| 客户360视图组件化 | 多标签页布局可复用，方便后续模块使用 | P0 |
| 客户查重算法优化 | 除名称/邮箱外，支持电话模糊匹配+名称相似度 | P1 |
| 可视化权限矩阵 | 矩阵式展示角色×资源的权限配置 | P1 |
| 客户公海池 | 未分配或超期未跟进的客户自动进入公海 | P1 |
| 销售管道看板自研 | 使用dnd-kit实现拖拽式看板 | P1 |
| API文档自动生成 | 基于OpenAPI规范自动生成，支持在线测试 | P1 |
| 登录安全策略 | 登录失败锁定、双因素认证、IP白名单 | P1 |
| 权限变更审批流 | 权限变更需审批，防止越权操作 | P2 |

---

## 七、版本历史

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v1.0 | 2026-04-23 | 初始版本：全局ERD + 按模块ERD + 关系符号对照表 |
| v1.1 | 2026-04-30 | 更新至3个子PRD最新数据模型：增加跨模块简化ERD、补充模块内字段详细定义、增加连线汇总表 |

---

*本文档整合了CRM-01客户管理、CRM-02销售管理、CRM-03权限安全三个模块的16张数据表，包含完整的实体关系图和字段定义。*
