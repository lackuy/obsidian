# CRM_v1.0_步骤2-分批次部署计划_2026年4月23日

> **创建日期**: 2026-04-23
> **创建人**: 产品规划师
> **需求来源**: [[01-工作区域/00-需求池/00001.CRM系统的功能合并报告+-20260407]]
> **项目版本**: v2.0

---

## 文档溯源

### 任务来源
| 项目 | 内容 |
|------|------|
| **任务名称** | CRM 系统产品实施 |
| **需求来源** | [[01-工作区域/00-需求池/00001.CRM系统的功能合并报告+-20260407]] |

### 上游文档
| 角色 | 文档链接 |
|------|---------|
| 功能评估与清单 | [[CRM_v1.0_步骤1-功能评估与清单_2026年4月23日]] |

---

## 一、部署总览

| 批次 | 模块 | 模块优先级 | 需要部署的项目 | 说明 |
|------|------|-----------|--------------|------|
| 第 1 批 | CRM-01 客户管理 + CRM-02 销售管理 | P0 | SuiteCRM（核心）, Odoo（核心）, Vtiger（核心） | 同项目去重复用，3 个项目覆盖 2 个模块 |
| 第 2 批 | CRM-03 权限安全 | P0 | Odoo（✅ 已部署，第 1 批）, NocoBase（核心） | Odoo 复用，新增 NocoBase |
| 第 3 批 | CRM-04 营销管理 + CRM-05 客服工单 + CRM-06 报表分析 | P1 | SuiteCRM（✅ 已部署，第 1 批）, Vtiger（✅ 已部署，第 1 批）, Odoo（✅ 已部署，第 1 批）, Huly（新增）, Twenty（新增） | 全部复用 + 新增 Huly、Twenty |
| 第 4 批 | CRM-07 项目管理 + CRM-08 协作功能 + CRM-09 财务管理 | P2 | Huly（✅ 已部署，第 3 批）, Odoo（✅ 已部署，第 1 批）, Twenty（✅ 已部署，第 3 批）, Akaunting（新增） | 大部分复用 + 新增 Akaunting |
| 第 5 批 | CRM-10 电商功能 + CRM-11 AI + CRM-12 低代码 + CRM-13 集成 + CRM-14 工作流 | P2 | ECShopX（新增）, Monica（新增）, NocoBase（✅ 已部署，第 2 批） | 新增 ECShopX、Monica，其余复用 |

**部署策略**：
- 按模块优先级分批：P0 → P1 → P2
- 核心-扩展分层：每模块最多 3 个核心项目立即部署
- 同项目去重复用：已部署项目在不同批次中直接复用
- 每批新增 1-3 个项目，控制部署规模
- 总计 10 个项目，分 5 批次递进部署

---

## 二、核心-扩展分层

### 第 1 批（CRM-01 + CRM-02）

**核心项目（3 个）**：
- ✅ SuiteCRM - 功能完整度最高（P0），覆盖客户管理+销售管理核心功能
- ✅ Odoo - 体验优秀 + 360 视图/销售管道看板亮点（P1）
- ✅ Vtiger - 线索评分独特亮点（P1）

**扩展项目（2 个，延迟部署）**：
- ⏸️ Twenty - 现代化 UI，但 Docker 部署复杂度高
- ⏸️ Monica - PRM 定位不同，非核心 CRM

### 第 2 批（CRM-03）

**核心项目（2 个）**：
- ✅ Odoo - 复用第 1 批已部署，完整权限模型
- ✅ NocoBase - 低代码权限配置，REST API 文档

**扩展项目（1 个，延迟部署）**：
- ⏸️ SuiteCRM - 团队级权限控制，可复用第 1 批

### 第 3 批（CRM-04 + CRM-05 + CRM-06）

**核心项目（5 个）**：
- ✅ SuiteCRM - 复用第 1 批，邮件营销+SLA+报表引擎
- ✅ Vtiger - 复用第 1 批，线索评分+工单自动分配
- ✅ Odoo - 复用第 1 批，电子表格+数据透视
- ✅ Huly - 新增部署，知识库+Markdown Wiki
- ✅ Twenty - 新增部署，现代仪表板 UI

**扩展项目（2 个，延迟部署）**：
- ⏸️ NocoBase - 数据透视表参考，可复用第 2 批
- ⏸️ SuiteCRM - 全文搜索参考，可复用第 1 批

### 第 4 批（CRM-07 + CRM-08 + CRM-09）

**核心项目（4 个）**：
- ✅ Huly - 复用第 3 批，敏捷看板+甘特图+IM
- ✅ Odoo - 复用第 1 批，任务管理+财务报表
- ✅ Twenty - 复用第 3 批，任务协作
- ✅ Akaunting - 新增部署，免费发票管理+银行对账

**扩展项目（1 个，延迟部署）**：
- ⏸️ SuiteCRM - Wiki 文档参考，可复用第 1 批

### 第 5 批（CRM-10 + CRM-11 + CRM-12 + CRM-13 + CRM-14）

**核心项目（3 个）**：
- ✅ ECShopX - 新增部署，完整电商流程
- ✅ Monica - 新增部署，AI 对话/内容生成
- ✅ NocoBase - 复用第 2 批，低代码+工作流+API 文档

**扩展项目（2 个，延迟部署）**：
- ⏸️ SuiteCRM - 工作流自动化参考，可复用第 1 批
- ⏸️ Odoo - AI 预测/客户细分参考，可复用第 1 批

---

## 三、分批次详情

### 第 1 批部署项目表

| 项目名 | 层级 | 状态 | 部署目录 | Docker 镜像 | 端口 | 说明 |
|--------|------|------|---------|------------|------|------|
| SuiteCRM | 核心 | 新部署 | `/home/ubuntu/workspace/projects/a-SuiteCRM/` | bitnami/suitecrm:latest | 8072 | 客户管理+销售管理核心参考 |
| Odoo | 核心 | 新部署 | `/home/ubuntu/workspace/projects/b-Odoo/` | odoo:17 | 8069 | 客户 360 视图+销售管道看板+权限模型 |
| Vtiger | 核心 | 新部署 | `/home/ubuntu/workspace/projects/c-Vtiger/` | sourcepass/vtiger:latest | 8073 | 线索评分+关系图谱 |

### 第 1 批验证功能清单

| 功能编号 | 功能名称 | 验证项目 | 验证要点 |
|---------|---------|---------|---------|
| CRM-01-01 | 客户列表 | SuiteCRM, Odoo | 列表展示、搜索、筛选、分页、排序 |
| CRM-01-02 | 新增客户 | SuiteCRM, Odoo | 表单字段齐全、必填校验、查重 |
| CRM-01-03 | 客户详情 | Odoo, SuiteCRM | 360 视图、标签页切换、关联数据 |
| CRM-01-04 | 联系人管理 | SuiteCRM | 联系人创建、编辑、与客户关联关系 |
| CRM-01-05 | 客户编辑 | SuiteCRM, Odoo | 编辑保存、查重校验、变更追溯 |
| CRM-01-06 | 客户删除 | SuiteCRM | 删除确认、软删除机制 |
| CRM-01-07 | 客户标签分类 | SuiteCRM | 标签创建、筛选、多维度管理 |
| CRM-02-01 | 线索管理 | SuiteCRM, Vtiger | 线索列表、状态筛选、评分 |
| CRM-02-02 | 商机管理 | SuiteCRM, Odoo | 商机创建、阶段流转、详情展示 |
| CRM-02-03 | 商机金额预测 | SuiteCRM | 阶段概率、加权金额计算 |
| CRM-02-04 | 报价管理 | SuiteCRM | 报价创建、版本管理、转订单 |
| CRM-02-05 | 销售漏斗看板 | Odoo | 看板视图、拖拽流转（Enterprise 限制） |
| CRM-02-06 | 关系图谱 | Vtiger | 可视化关联关系（如可用） |

### 第 2 批部署项目表

| 项目名 | 层级 | 状态 | 部署目录 | Docker 镜像 | 端口 | 说明 |
|--------|------|------|---------|------------|------|------|
| Odoo | 核心 | ✅ 已部署（第 1 批） | `/home/ubuntu/workspace/projects/b-Odoo/` | odoo:17 | 8069 | 复用第 1 批 |
| NocoBase | 核心 | 新部署 | `/home/ubuntu/workspace/projects/d-NocoBase/` | nocobase/nocobase:latest | 8083 | 低代码权限配置+API 文档 |

### 第 2 批验证功能清单

| 功能编号 | 功能名称 | 验证项目 | 验证要点 |
|---------|---------|---------|---------|
| CRM-03-01 | 用户管理 | Odoo, NocoBase | 用户创建、编辑、角色分配、密码重置 |
| CRM-03-02 | 角色管理 | Odoo | 角色创建、权限配置、继承关系 |
| CRM-03-03 | 行级数据权限 | Odoo, NocoBase | 数据按负责人/团队隔离 |
| CRM-03-04 | 字段级权限 | Odoo, NocoBase | 列级可见/编辑/隐藏 |
| CRM-03-05 | 操作权限 | Odoo, NocoBase | 增删改查操作级控制 |
| CRM-03-06 | 审计日志 | Odoo, NocoBase | 操作记录、变更历史、筛选查询 |
| CRM-03-07 | OAuth2 认证 | - | 第三方登录集成（如可配置） |
| CRM-03-08 | REST API + 文档 | NocoBase | API 文档、在线测试、Token 管理 |

### 第 3 批部署项目表

| 项目名 | 层级 | 状态 | 部署目录 | Docker 镜像 | 端口 | 说明 |
|--------|------|------|---------|------------|------|------|
| SuiteCRM | 核心 | ✅ 已部署（第 1 批） | `/home/ubuntu/workspace/projects/a-SuiteCRM/` | bitnami/suitecrm:latest | 8072 | 复用第 1 批 |
| Vtiger | 核心 | ✅ 已部署（第 1 批） | `/home/ubuntu/workspace/projects/c-Vtiger/` | sourcepass/vtiger:latest | 8073 | 复用第 1 批 |
| Odoo | 核心 | ✅ 已部署（第 1 批） | `/home/ubuntu/workspace/projects/b-Odoo/` | odoo:17 | 8069 | 复用第 1 批 |
| Huly | 核心 | 新部署 | `/home/ubuntu/workspace/projects/e-Huly/` | huly/huly:latest | 8084 | 知识库+Markdown Wiki |
| Twenty | 核心 | 新部署 | `/home/ubuntu/workspace/projects/f-Twenty/` | twentycrm/twenty:latest | 8085 | 现代仪表板 UI+趋势分析 |

### 第 3 批验证功能清单

| 功能编号 | 功能名称 | 验证项目 | 验证要点 |
|---------|---------|---------|---------|
| CRM-04-01 | 营销活动创建 | SuiteCRM, Vtiger, Odoo | 预算/目标/时间设置、活动类型选择 |
| CRM-04-02 | 活动目标列表 | SuiteCRM, Vtiger, Odoo | 目标列表管理、筛选、关联活动 |
| CRM-04-03 | 活动 ROI 跟踪 | SuiteCRM, Vtiger, Odoo | ROI 计算、报表展示 |
| CRM-04-04 | 邮件模板管理 | SuiteCRM, Vtiger, Odoo | 模板创建、可视化编辑 |
| CRM-04-05 | 邮件群发 | SuiteCRM, Vtiger, Odoo | 定时发送、分批发送 |
| CRM-04-06 | 邮件追踪 | SuiteCRM, Twenty | 打开率/点击率统计 |
| CRM-05-01 | 工单创建 | SuiteCRM, Vtiger, Odoo | 多渠道创建（邮件/门户/手动） |
| CRM-05-02 | 工单分配 | SuiteCRM, Vtiger, Odoo | 自动分配/手动/自我认领 |
| CRM-05-03 | 工单升级 | SuiteCRM, Vtiger, Odoo | 超时自动升级、规则配置 |
| CRM-05-04 | SLA 管理 | SuiteCRM, Vtiger | SLA 定义、响应/解决时间 |
| CRM-05-05 | 知识库管理 | SuiteCRM, Huly | 富文本编辑、Markdown、版本控制 |
| CRM-05-06 | 知识全文搜索 | SuiteCRM, Huly | Elasticsearch 全文搜索 |
| CRM-06-01 | 仪表板 | Twenty, SuiteCRM, Odoo | 卡片展示、图表组件 |
| CRM-06-02 | 自定义报表 | SuiteCRM, Vtiger, Odoo | AOR 报表引擎、自定义列/筛选 |
| CRM-06-03 | 数据透视表 | Odoo, NocoBase | 拖拽式透视、电子表格集成 |
| CRM-06-04 | 趋势分析 | Twenty, SuiteCRM, Odoo | 历史数据趋势可视化 |
| CRM-06-05 | 报表导出 | SuiteCRM, Vtiger, Odoo | PDF/Excel/CSV 多格式导出 |

### 第 4 批部署项目表

| 项目名 | 层级 | 状态 | 部署目录 | Docker 镜像 | 端口 | 说明 |
|--------|------|------|---------|------------|------|------|
| Huly | 核心 | ✅ 已部署（第 3 批） | `/home/ubuntu/workspace/projects/e-Huly/` | huly/huly:latest | 8084 | 复用第 3 批 |
| Odoo | 核心 | ✅ 已部署（第 1 批） | `/home/ubuntu/workspace/projects/b-Odoo/` | odoo:17 | 8069 | 复用第 1 批 |
| Twenty | 核心 | ✅ 已部署（第 3 批） | `/home/ubuntu/workspace/projects/f-Twenty/` | twentycrm/twenty:latest | 8085 | 复用第 3 批 |
| Akaunting | 核心 | 新部署 | `/home/ubuntu/workspace/projects/g-Akaunting/` | akaunting/akaunting:latest | 8086 | 免费发票管理+银行对账 |

### 第 4 批验证功能清单

| 功能编号 | 功能名称 | 验证项目 | 验证要点 |
|---------|---------|---------|---------|
| CRM-07-01 | 任务管理 | Huly, Odoo, SuiteCRM | 敏捷看板、甘特图、任务依赖 |
| CRM-07-02 | 看板与视图 | Huly, Twenty, Odoo | 多视图（看板/时间线/表格） |
| CRM-07-03 | 任务分配 | Huly, Twenty, Odoo | 指派/协作/状态流转 |
| CRM-07-04 | Wiki 文档 | Huly, Odoo | Markdown 编辑、版本历史 |
| CRM-07-05 | 子任务分解 | Huly, Odoo | 无限级子任务嵌套 |
| CRM-08-01 | 实时评论 | Huly, Twenty, Odoo | 实时评论、@提及、通知 |
| CRM-08-02 | 即时通讯 | Huly, Twenty | 内置 IM 聊天 |
| CRM-08-03 | @提及通知 | Huly, Twenty, SuiteCRM | @提及实时推送通知 |
| CRM-09-01 | 发票管理 | Akaunting, Odoo, Vtiger | 完整发票 CRUD、无手续费 |
| CRM-09-02 | 财务报表 | Akaunting, Odoo | Blade 模板报表 |
| CRM-09-03 | 银行对账 | Akaunting, Odoo | 规则匹配自动对账 |
| CRM-09-04 | 收款登记 | Akaunting, Odoo, Vtiger | 无手续费收款 |

### 第 5 批部署项目表

| 项目名 | 层级 | 状态 | 部署目录 | Docker 镜像 | 端口 | 说明 |
|--------|------|------|---------|------------|------|------|
| ECShopX | 核心 | 新部署 | `/home/ubuntu/workspace/projects/h-ECShopX/` | ecshopx/ecshopx:latest | 8087 | 完整电商流程 |
| Monica | 核心 | 新部署 | `/home/ubuntu/workspace/projects/i-Monica/` | monica:latest | 8088 | AI 对话/内容生成 |
| NocoBase | 核心 | ✅ 已部署（第 2 批） | `/home/ubuntu/workspace/projects/d-NocoBase/` | nocobase/nocobase:latest | 8083 | 复用第 2 批 |

### 第 5 批验证功能清单

| 功能编号 | 功能名称 | 验证项目 | 验证要点 |
|---------|---------|---------|---------|
| CRM-10-01 | 商品创建 | ECShopX, Bagisto, Odoo | SPU/SKU 分离、属性管理 |
| CRM-10-02 | 商品规格管理 | ECShopX, Bagisto, Odoo | 属性继承体系 |
| CRM-10-03 | 库存管理 | Odoo, ECShopX | 库位/批次/序列号、多仓库 |
| CRM-10-04 | 订单列表 | ECShopX, Bagisto, Odoo | 多条件筛选、全渠道 |
| CRM-10-05 | 订单处理 | ECShopX, Bagisto, Odoo | 完整订单流程 |
| CRM-10-06 | 会员管理 | ECShopX, Bagisto, Odoo | 会员等级+积分体系 |
| CRM-10-07 | 物流配送 | ECShopX, Bagisto, Odoo | 运费模板+物流追踪 |
| CRM-10-08 | 售后管理 | ECShopX, Bagisto, Odoo | 退换货维修流程 |
| CRM-11-01 | AI 对话助手 | Monica, Odoo | 多轮上下文对话 |
| CRM-11-02 | AI 内容生成 | Monica, Odoo | 写作/润色/邮件回复 |
| CRM-11-03 | AI 销售预测 | Odoo, Twenty, SuiteCRM | Python AI/ML 预测 |
| CRM-11-04 | AI 客户细分 | Odoo, SuiteCRM, Vtiger | Python 生态 AI/ML 客户细分 |
| CRM-12-01 | 可视化数据建模 | NocoBase, Odoo | 可视化创建数据模型/字段/关系 |
| CRM-12-02 | 字段管理 | NocoBase, Odoo | 20+ 字段类型、动态字段 |
| CRM-12-03 | 页面设计器 | NocoBase, Odoo | 拖拽构建页面 |
| CRM-12-04 | 区块组件 | NocoBase, Odoo | 丰富组件库可复用 |
| CRM-12-05 | 关系管理 | NocoBase, Odoo | 1:1/1:N/N:M 关系定义 |
| CRM-13-01 | REST API | Twenty, SuiteCRM, Vtiger, Odoo, NocoBase | 标准 REST API |
| CRM-13-02 | GraphQL | Twenty, NocoBase | 原生 GraphQL API |
| CRM-13-03 | API 文档 | Twenty, SuiteCRM, NocoBase | 自动生成文档+在线测试 |
| CRM-13-04 | Webhook | Twenty, SuiteCRM, Vtiger, Odoo | 四种触发器类型 |
| CRM-13-05 | 第三方集成 | Twenty, SuiteCRM, Vtiger, Odoo | OAuth2、邮件集成等 |
| CRM-14-01 | 流程画布 | NocoBase, Odoo, SuiteCRM, Vtiger | AOW_WorkFlow 完整可视化流程 |
| CRM-14-02 | 触发器类型 | NocoBase, SuiteCRM, Vtiger | 事件/定时/手动/条件触发器 |
| CRM-14-03 | 自动化规则 | Huly, Twenty, SuiteCRM, Odoo | 现代自动化规则引擎 |
| CRM-14-04 | 节点配置 | NocoBase, SuiteCRM, Vtiger, Odoo | 可视化流程编排 |

---

## 四、部署项目汇总

| 序号 | 项目名 | 部署目录 | 端口 | 部署批次 | 说明 |
|------|--------|---------|------|---------|------|
| 1 | SuiteCRM | `/home/ubuntu/workspace/projects/a-SuiteCRM/` | 8072 | 第 1 批 | 客户管理+销售管理+邮件营销+SLA+报表 |
| 2 | Odoo | `/home/ubuntu/workspace/projects/b-Odoo/` | 8069 | 第 1 批 | 360 视图+权限模型+销售看板+电子表格 |
| 3 | Vtiger | `/home/ubuntu/workspace/projects/c-Vtiger/` | 8073 | 第 1 批 | 线索评分+关系图谱+工单分配 |
| 4 | NocoBase | `/home/ubuntu/workspace/projects/d-NocoBase/` | 8083 | 第 2 批 | 低代码+权限配置+API 文档+工作流 |
| 5 | Huly | `/home/ubuntu/workspace/projects/e-Huly/` | 8084 | 第 3 批 | 项目管理+知识库+IM+甘特图 |
| 6 | Twenty | `/home/ubuntu/workspace/projects/f-Twenty/` | 8085 | 第 3 批 | 现代 UI+仪表板+任务协作 |
| 7 | Akaunting | `/home/ubuntu/workspace/projects/g-Akaunting/` | 8086 | 第 4 批 | 免费发票管理+银行对账 |
| 8 | ECShopX | `/home/ubuntu/workspace/projects/h-ECShopX/` | 8087 | 第 5 批 | 完整电商流程 |
| 9 | Monica | `/home/ubuntu/workspace/projects/i-Monica/` | 8088 | 第 5 批 | AI 对话/内容生成 |

---

## 版本历史

| 版本 | 日期 | 变更内容 | 变更人 |
|------|------|---------|--------|
| v1.0 | 2026-04-20 | 初始版本 | 产品规划师 |
| v1.0 | 2026-04-22 | 重新制定部署计划，明确核心/扩展分层 | 产品规划师 |
| v1.1 | 2026-04-23 | 重新产出角色1产物，保持内容一致性 | 产品规划师 |
| v2.0 | 2026-04-23 | 补全全部 14 模块 5 批次部署计划（原仅 3 模块 2 批次），新增 10 个项目总览 | 产品规划师 |
