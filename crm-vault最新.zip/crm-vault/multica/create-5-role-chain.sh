#!/bin/bash
# create-5-role-chain.sh
# 五个角色链式任务创建脚本
# 使用方式: ./create-5-role-chain.sh

set -e

echo "=========================================="
echo "  创建五个角色的链式任务"
echo "=========================================="

# 获取当前日期
DATE_STR=$(date +%Y年%m月%d日)

echo ""
echo "任务日期: $DATE_STR"
echo ""

# ========== 角色1: 市场调研员 ==========
echo "【步骤1/5】创建角色1任务: 市场调研员..."
ISSUE1=$(multica issue create \
  --title "SCRM市场调研 - $DATE_STR" \
  --description "## 任务描述
基于开源项目列表，完成市场调研素材包

## 执行步骤
1. 使用 skill-crm-core 读取项目配置和 CLAUDE.md 工作流
2. 使用 skill-crm-core 读取角色规范（02-角色视图/1.市场调研员.md）
3. 搜集3~15个开源CRM项目信息
4. 产出《市场调研素材包》

## 输出要求
- 目录: 01-工作区域/04-已交付/1.市场调研员/
- 文件: SCRM_v1.0_市场调研素材包_$DATE_STR.md
- 内容: 3~15个开源项目信息（名称、GitHub地址、技术栈、功能特点）

## 下游依赖
- 角色2（竞品分析师）依赖本任务产出" \
  --assignee "市场调研员角色1" \
  --output json 2>/dev/null | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)

if [ -z "$ISSUE1" ]; then
  echo "❌ 角色1任务创建失败"
  exit 1
fi

echo "✅ 角色1任务创建成功"
echo "   ID: $ISSUE1"
echo "   标题: SCRM市场调研 - $DATE_STR"


# ========== 角色2: 竞品分析师 ==========
echo ""
echo "【步骤2/5】创建角色2任务: 竞品分析师..."
ISSUE2=$(multica issue create \
  --title "SCRM竞品深度分析 - $DATE_STR" \
  --description "## 任务描述
基于市场调研素材包，完成竞品深度分析

## 上游依赖
- 角色1产出: 01-工作区域/04-已交付/1.市场调研员/SCRM_v1.0_市场调研素材包_$DATE_STR.md

## 执行前检查
1. 检查上游文件是否存在
2. 如不存在，返回'等待上游完成'并暂停
3. 如存在，继续执行

## 执行步骤
1. 使用 skill-crm-core 读取项目配置
2. 读取上游《市场调研素材包》
3. 使用 skill-crm-core 读取角色规范（02-角色视图/2.竞品分析师.md）
4. 选择3~15个项目进行深度分析（P0:5-8个, P1:5-7个）
5. 完成商业场景、解决方案、功能点、技术特点、SWOT分析
6. 制作功能级对比矩阵
7. 提炼≥10个亮点功能
8. 产出《竞品分析报告》

## 输出要求
- 目录: 01-工作区域/04-已交付/2.竞品分析师/
- 文件: SCRM_v1.0_竞品分析报告_$DATE_STR.md

## 下游依赖
- 角色3（需求规划师）依赖本任务产出" \
  --assignee "竞品分析师角色2" \
  --parent "$ISSUE1" \
  --output json 2>/dev/null | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)

if [ -z "$ISSUE2" ]; then
  echo "❌ 角色2任务创建失败"
  exit 1
fi

echo "✅ 角色2任务创建成功"
echo "   ID: $ISSUE2"
echo "   标题: SCRM竞品深度分析 - $DATE_STR"
echo "   父任务: $ISSUE1"


# ========== 角色3: 需求规划师 ==========
echo ""
echo "【步骤3/5】创建角色3任务: 需求规划师..."
ISSUE3=$(multica issue create \
  --title "SCRM需求规划 - $DATE_STR" \
  --description "## 任务描述
基于市场调研和竞品分析，完成需求规划

## 上游依赖
- 角色1产出: 01-工作区域/04-已交付/1.市场调研员/SCRM_v1.0_市场调研素材包_$DATE_STR.md
- 角色2产出: 01-工作区域/04-已交付/2.竞品分析师/SCRM_v1.0_竞品分析报告_$DATE_STR.md

## 执行前检查
1. 检查两个上游文件是否都存在
2. 如任一不存在，返回'等待上游完成'并暂停
3. 如都存在，继续执行

## 执行步骤
1. 使用 skill-crm-core 读取项目配置
2. 读取上游两份文档
3. 使用 skill-crm-core 读取角色规范（02-角色视图/3.需求规划师.md）
4. 识别≥3个核心研发场景
5. 制定SMART项目目标（MVP/v1.1/v2.0）
6. 制定标准指标（性能/功能/体验/技术）
7. 制作功能索引表（标注已存在/待更新/新增）
8. 执行自检澄清（待确认项≤2）
9. 产出三份文档

## 输出要求
- 目录: 01-工作区域/04-已交付/3.需求规划师/
- 文件1: SCRM_v1.0_产品需求池报告_$DATE_STR.md
- 文件2: SCRM_v1.0_功能索引表_$DATE_STR.md
- 文件3: SCRM_v1.0_需求澄清清单_$DATE_STR.md

## 下游依赖
- 角色4（产品规划师）依赖本任务产出" \
  --assignee "需求规划师角色3" \
  --parent "$ISSUE2" \
  --output json 2>/dev/null | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)

if [ -z "$ISSUE3" ]; then
  echo "❌ 角色3任务创建失败"
  exit 1
fi

echo "✅ 角色3任务创建成功"
echo "   ID: $ISSUE3"
echo "   标题: SCRM需求规划 - $DATE_STR"
echo "   父任务: $ISSUE2"


# ========== 角色4: 产品规划师 ==========
echo ""
echo "【步骤4/5】创建角色4任务: 产品规划师..."
ISSUE4=$(multica issue create \
  --title "SCRM产品规划 - $DATE_STR" \
  --description "## 任务描述
基于需求规划，完成产品规划

## 上游依赖
- 角色3产出: 01-工作区域/04-已交付/3.需求规划师/SCRM_v1.0_产品需求池报告_$DATE_STR.md
- 角色3产出: 01-工作区域/04-已交付/3.需求规划师/SCRM_v1.0_功能索引表_$DATE_STR.md
- 角色3产出: 01-工作区域/04-已交付/3.需求规划师/SCRM_v1.0_需求澄清清单_$DATE_STR.md

## 执行前检查
1. 检查三个上游文件是否都存在
2. 如任一不存在，返回'等待上游完成'并暂停
3. 如都存在，继续执行

## 执行步骤
1. 使用 skill-crm-core 读取项目配置
2. 读取上游三份文档
3. 使用 skill-crm-core 读取角色规范（02-角色视图/4.产品规划师.md）
4. 执行需求鉴定、模块拆分
5. 制定功能清单
6. 制定分批次部署计划
7. 初始化《项目状态总览》
8. 产出两份文档

## 输出要求
- 目录: 01-工作区域/04-已交付/4.产品规划师/
- 文件1: SCRM_v1.0_功能评估与清单_$DATE_STR.md
- 文件2: SCRM_v1.0_分批次部署计划_$DATE_STR.md

## 下游依赖
- 角色5（架构验证师）依赖本任务产出" \
  --assignee "产品规划师角色4" \
  --parent "$ISSUE3" \
  --output json 2>/dev/null | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)

if [ -z "$ISSUE4" ]; then
  echo "❌ 角色4任务创建失败"
  exit 1
fi

echo "✅ 角色4任务创建成功"
echo "   ID: $ISSUE4"
echo "   标题: SCRM产品规划 - $DATE_STR"
echo "   父任务: $ISSUE3"


# ========== 角色5: 架构验证师 ==========
echo ""
echo "【步骤5/5】创建角色5任务: 架构验证师..."
ISSUE5=$(multica issue create \
  --title "SCRM架构验证 - $DATE_STR" \
  --description "## 任务描述
基于产品规划，完成技术架构验证

## 上游依赖
- 角色4产出: 01-工作区域/04-已交付/4.产品规划师/SCRM_v1.0_功能评估与清单_$DATE_STR.md
- 角色4产出: 01-工作区域/04-已交付/4.产品规划师/SCRM_v1.0_分批次部署计划_$DATE_STR.md

## 执行前检查
1. 检查两个上游文件是否都存在
2. 如任一不存在，返回'等待上游完成'并暂停
3. 如都存在，继续执行

## 执行步骤
1. 使用 skill-crm-core 读取项目配置
2. 读取上游两份文档
3. 使用 skill-crm-core 读取角色规范（02-角色视图/5.架构验证师.md）
4. 识别核心/扩展项目
5. 按需部署开源项目
6. 执行部署验证
7. 执行QA测试
8. 更新《项目状态总览》
9. 产出两份报告

## 输出要求
- 目录: 01-工作区域/04-已交付/5.架构验证师/
- 文件1: SCRM_v1.0_部署验证报告_$DATE_STR.md
- 文件2: SCRM_v1.0_QA测试报告_$DATE_STR.md

## 下游依赖
- 角色6（产品分析师）与本角色形成迭代循环" \
  --assignee "架构验证师角色5" \
  --parent "$ISSUE4" \
  --output json 2>/dev/null | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)

if [ -z "$ISSUE5" ]; then
  echo "❌ 角色5任务创建失败"
  exit 1
fi

echo "✅ 角色5任务创建成功"
echo "   ID: $ISSUE5"
echo "   标题: SCRM架构验证 - $DATE_STR"
echo "   父任务: $ISSUE4"


# ========== 完成汇总 ==========
echo ""
echo "=========================================="
echo "  任务链创建完成！"
echo "=========================================="
echo ""
echo "执行顺序:"
echo "  $ISSUE1 → $ISSUE2 → $ISSUE3 → $ISSUE4 → $ISSUE5"
echo ""
echo "角色对应:"
echo "  角色1(市场调研员) → 角色2(竞品分析师) → 角色3(需求规划师)"
echo "  → 角色4(产品规划师) → 角色5(架构验证师)"
echo ""
echo "查看任务列表:"
echo "  multica issue list"
echo ""
echo "查看任务详情:"
echo "  multica issue get $ISSUE1"
echo "  multica issue get $ISSUE2"
echo "  ..."
echo ""
