# skill-crm-core

## 功能
CRM 项目核心技能包 - 整合配置读取、角色加载、Git 提交

## 项目配置
```json
{
  "项目": "CRM",
  "路径": "/home/ubuntu/workspace/crm-vault",
  "角色视图目录": "/home/ubuntu/workspace/crm-vault/02-角色视图",
  "产出物目录": "/home/ubuntu/workspace/crm-vault/01-工作区域/04-已交付",
  "Git仓库": "repo-crm-vault"
}
```

## 指令 1: 读取 CLAUDE.md 工作流
读取 `/home/ubuntu/workspace/crm-vault/CLAUDE.md`，返回工作流规范

## 指令 2: 加载角色规范
根据角色名读取对应文件：
- 市场调研员 → `02-角色视图/1.市场调研员.md`
- 竞品分析师 → `02-角色视图/2.竞品分析师.md`
- 需求规划师 → `02-角色视图/3.需求规划师.md`
- 产品规划师 → `02-角色视图/4.产品规划师.md`
- 架构验证师 → `02-角色视图/5.架构验证师.md`
- 产品分析师 → `02-角色视图/6.产品分析师.md`
- 原型工程师 → `02-角色视图/7.原型工程师.md`

## 指令 3: Git 提交
1. 进入项目目录
2. `git add .`
3. `git commit -m "[{角色名}] {操作描述} - {日期}"`
4. `git push`（如有远程仓库）

## Issue 极简模板
```
角色: 市场调研员
模式: 单角色
任务: 分析竞品功能对比
```
